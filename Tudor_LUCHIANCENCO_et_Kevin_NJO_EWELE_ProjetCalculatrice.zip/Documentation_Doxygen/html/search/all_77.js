var searchData=
[
  ['what',['what',['../classCalculatriceException.html#a4c5cb709fec6dbbd0a059544937440c4',1,'CalculatriceException']]]
];
